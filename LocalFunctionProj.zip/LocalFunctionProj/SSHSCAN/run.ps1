function Test-Port {
    param (
        [string]$ComputerName,
        [int]$PortNumber
    )
 
    try {
        $tcpclient = New-Object System.Net.Sockets.TcpClient
        $tcpclient.Connect($ComputerName, $PortNumber)
        $tcpclient.Close()
        return $true
    }
    catch {
        return $false
    }
}
 
# Lista de portas a serem verificadas
$ports = @(22, 80, 8080, 30000, 30718, 30951, 31038)
$domain = "cp.leosantos.seg.br"
 
foreach ($port in $ports) {
    if (Test-Port -ComputerName $domain -PortNumber $port) {
        Write-Host "A porta $port está aberta no domínio $domain."
    } else {
        Write-Host "A porta $port está fechada no domínio $domain."
    }
}